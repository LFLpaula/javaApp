/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package net.LFDPoo.modelos;

/**
 *
 * @author puc
 */
public class telefone {
    private int ddi = 0;
    private int ddd = 0;
    private int numero = 0;

     public telefone(int ddi, int ddd, int numero) throws Exception {
        if (ddi <= 0 || ddi > 99) {
            throw new Exception("O DDI deve estar entre 1 e 99.");
        }
        this.ddi = ddi;

        if (ddd <= 0 || ddd > 99) {
            throw new Exception("O DDD deve estar entre 1 e 99.");
        }
        this.ddd = ddd;

        if (numero <= 0) {
            throw new Exception("O número não pode ser menor ou igual a 0.");
        }
        this.numero = numero;
    }

    // Construtor vazio
    public telefone() {
    }

    // Getters e Setters com validações
    public int getDdi() {
        return ddi;
    }

    public void setDdi(int ddi) throws Exception {
        if (ddi <= 0 || ddi > 99) {
            throw new Exception("O DDI deve estar entre 1 e 99.");
        }
        this.ddi = ddi;
    }

    public int getDdd() {
        return ddd;
    }

    public void setDdd(int ddd) throws Exception {
        if (ddd <= 0 || ddd > 99) {
            throw new Exception("O DDD deve estar entre 1 e 99.");
        }
        this.ddd = ddd;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) throws Exception {
        if (numero <= 0) {
            throw new Exception("O número não pode ser menor ou igual a 0.");
        }
        this.numero = numero;
    }

    // Método de validação completa
    public boolean validarTelefone() {
        return ddi > 0 && ddi <= 99 &&
               ddd > 0 && ddd <= 99 &&
               numero > 0;
    }

    // Método para formatar o telefone
    public String formatarTelefone() {
        return "+" + ddi + " (" + ddd + ") " + String.format("%09d", numero);
    }

    @Override
    public String toString() {
        return ddi + ";" + ddd + ";" + numero;
    }
}
    
   