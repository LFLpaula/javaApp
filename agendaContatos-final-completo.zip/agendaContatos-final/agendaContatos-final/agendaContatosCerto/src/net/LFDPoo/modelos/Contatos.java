/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package net.LFDPoo.modelos;
import net.LFDPoo.enumeração.enumSexo;





/**
 *
 * @author puc
 */
public class Contatos {
    private int idContato= 0;
    public String nome = "";
    public telefone fone = null;
    private enumSexo sexo = null;
    private String email = "";

    public Contatos() {
    }

    public Contatos(int idContato, String nome, telefone fone,enumSexo sexo, String email) {
        this.idContato = idContato;
        this.nome = nome;
        this.fone = fone;
        this.sexo = sexo;
        this.email = email;
    }

    public int getIdContato() {
        return idContato;
    }

    public void setIdContato(int idContato) {
        this.idContato = idContato;
    }

    public String getNome() {
        return nome.toUpperCase();
    }

    public void setNome(String nome) {
        this.nome = nome.toUpperCase();
    }

    public telefone getFone() {
        return fone;
    }

    public void setFone(telefone fone) {
        this.fone = fone;
    }

    public enumSexo getSexo() {
        return sexo;
    }

    public void setSexo(enumSexo sexo) {
        
        this.sexo = sexo;
    }

    public String getEmail() {
        return email;
    }

    /*public boolean validarEmail(String email) {
        return email != null && email.matches("^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$");
    }*/
    
    public void setEmail(String email) {
       // if (validarEmail(email)) {
            this.email = email;
        //} else {
        //    throw new IllegalArgumentException("E-mail inválido.");
        //}
    }
    
 
    
    
    
    
    
}
