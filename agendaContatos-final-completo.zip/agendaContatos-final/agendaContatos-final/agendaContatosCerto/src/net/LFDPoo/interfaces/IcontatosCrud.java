/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package net.LFDPoo.interfaces;
import net.LFDPoo.modelos.Contatos;
import java.util.List;

/**
 *
 * @author puc
 */
public interface IcontatosCrud {
    public void incluir(Contatos pessoa)throws Exception;
    public void alterar(Contatos pessoa)throws Exception;
    public void excluir(int identificador)throws Exception;
    public Contatos consultar(int identificador)throws Exception;
    public Contatos consultar(String nome)throws Exception;
    public List<Contatos> ListagemDeContatos()throws Exception;
    
    
}
