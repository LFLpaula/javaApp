/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package net.LFDPoo.controle;
import java.util.List;
import net.LFDPoo.interfaces.IcontatosCrud;
import net.LFDPoo.modelos.Contatos;

import net.LFDPoo.persistencia.contatoDAO;

/**
 *
 * @author puc
 */
public class controleContato  implements IcontatosCrud{
    IcontatosCrud persistenciaContatos = null;
    
    public controleContato() throws Exception {
        try{
         persistenciaContatos = new contatoDAO();
            System.out.println("Inside Obj Creation Fiene");
        }catch (Exception erro){
          throw erro;
        }
    }

    @Override
    public void incluir(Contatos pessoa) throws Exception {
        try{
            validar(pessoa);
            persistenciaContatos.incluir(pessoa);
           throw new Exception(("controle sendo executado- incluir"));
          
      }catch(Exception erro){
           throw erro;
          
      }
    }

    @Override
    public void alterar(Contatos pessoa) throws Exception {
        try{
             validar(pessoa);
             persistenciaContatos.alterar(pessoa);
           throw new Exception(("controle sendo executado- alterar"));
          
      }catch(Exception erro){
           throw erro;   
      } 
    }

    @Override
    public void excluir(int identificador) throws Exception {
         try{
              persistenciaContatos.excluir(identificador);
           throw new Exception(("controle sendo executado- excluir"));
          
      }catch(Exception erro){
           throw erro;
          
      }
    }

    @Override
    public Contatos consultar(int identificador) throws Exception {
           try {
            if (identificador <= 0) {
                throw new Exception("O Identificador deve ser maior que 0.");
            }
            return persistenciaContatos.consultar(identificador);
        } catch (Exception e) {
            System.err.println("Erro ao consultar contato pelo ID: " + e.getMessage());
            throw e;
        }
    }
    @Override
    public List<Contatos> ListagemDeContatos() throws Exception {
          try{
               
               return persistenciaContatos.ListagemDeContatos();
               
           
          
      }catch(Exception erro){
           System.err.println("Erro ao listar contatos: " + erro.getMessage());
           throw erro;
          
      }
       
    }
    @Override
    public Contatos consultar(String nome) throws Exception {
         try {
            if (nome == null || nome.isEmpty()) {
                throw new Exception("O nome não pode ser vazio ou nulo.");
            }
            return persistenciaContatos.consultar(nome);
        } catch (Exception e) {
            System.err.println("Erro ao consultar contato pelo nome: " + e.getMessage());
            throw e;
        }      
    }

    
    public void validar(Contatos objeto) throws Exception {
        if(!objeto.getNome().matches("^[a-zA-Z0-9 ]+$"))throw new Exception( "Esse campo (nome) somente aceita letras\n");
        if(!objeto.getEmail().matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"))throw new Exception( "Esse campo (email) recebeu um email invalido.\n");
        if((objeto.getFone().getDdi()) == 0 || (objeto.getFone().getDdi()) >99) throw new Exception( "Informe um (DDI) de telefone valido.\n");
        if((objeto.getFone().getDdd()) < 11 || (objeto.getFone().getDdd()) >99) throw new Exception( "Informe um (DDD) de telefone valido.\n");
        String ddi = Integer.toString(objeto.getFone().getDdi());
        if(!ddi.matches("[0-9]+")) throw new Exception( "Esse campo (DDI) somente aceita numeros.\n");
        String ddd = Integer.toString(objeto.getFone().getDdd());
        if(!ddd.matches("[0-9]+")) throw new Exception( "Esse campo (DDD) somente aceita numeros.\n");
        String numero = Integer.toString(objeto.getFone().getNumero());
        if(!numero.matches("[0-9]+")) throw new Exception( "Esse campo (numero) somente aceita numeros.\n");
    }
    
    
    
        
    
    
    
}
